module.exports = {
    API_KEY: "01c969a061b9ee9ab694f108428555b9",
  };